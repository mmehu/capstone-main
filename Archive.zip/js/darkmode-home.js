function toggleTheme() {
    document.body.classList.toggle('dark-mode');
  }